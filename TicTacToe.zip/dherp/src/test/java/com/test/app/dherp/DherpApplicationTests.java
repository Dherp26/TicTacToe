package com.test.app.dherp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DherpApplicationTests {

	@Test
	void contextLoads() {
	}

}
