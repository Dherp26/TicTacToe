package com.test.app.dherp.constant;

/**
 * Constant for jwt.
 */
public final class JwtConstant {
    public static final String PERMISSIONS = "permissions";
    public static final String EMAIL = "email";
}
