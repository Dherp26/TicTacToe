package com.test.app.dherp.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
@Setter
@Getter
public class Game {

    public enum PlayerNumber {
        PLAYER_1,
        PLAYER_2
    }

    public enum PlayerType {
        PLAYER_1,
        PLAYER_2;
    }

    public enum GameState {
        IN_PROGRESS,
        PLAYER_1_WIN,
        PLAYER_2_WIN,
        DRAW
    }

    @Id
    @GeneratedValue
    private Long id;
    private int boardSize;

    @ManyToOne
    private AppUser appUser;

    private PlayerType player1;

    private PlayerType player2;

    private PlayerNumber nextMove;

    private GameState state;

}
