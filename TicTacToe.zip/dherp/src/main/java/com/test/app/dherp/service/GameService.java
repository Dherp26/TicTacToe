package com.test.app.dherp.service;

import com.test.app.dherp.model.AppUser;
import com.test.app.dherp.model.Game;
import com.test.app.dherp.repository.GameRepository;
import com.test.app.dherp.util.BoardUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tictactoe.game.entity.Game.GameState;
import tictactoe.game.entity.Game.PlayerNumber;

import java.util.List;

@Service
public class GameService {

	private final GameRepository gameRepository;

	@Autowired
	public GameService(GameRepository gameRepository) {
		this.gameRepository = gameRepository;
	}

	@Transactional
	public Game create(AppUser appUser, boolean playerGoFirst) {

		gameRepository.deleteUserGames(appUser);

		Game game = new Game();
		game.setAppUser(appUser);
		game.setState(Game.GameState.IN_PROGRESS);
		game.setNextMove(Game.PlayerNumber.PLAYER_1);

		//Size of tictactoe
		System.out.print("Insert size of tic tac toe board : ");

		int boardSize = game.getBoardSize();
		char[][] board = new char[boardSize][boardSize];

		//Create board
		for (int i = 0; i < boardSize; i++) {
			for (int j = 0; j < boardSize; j++) {
				board[i][j] = '=';
			}
		}
		game.setPlayer1(Game.PlayerType.valueOf("P1"));
		game.setPlayer2(Game.PlayerType.valueOf("P2"));


		BoardUtil.createEmpty(boardSize);

		gameRepository.save(game);

		return game;
	}

	public Game getLastGame(AppUser appUser) {
		return gameRepository.findFirstByAppUserOrderByIdDesc(appUser);
	}

	public void takeTurn(Game game, String tileId) {
		if (game.getState() != Game.GameState.IN_PROGRESS) {
			return;
		}

		String[] indices = tileId.split("-");
		if (indices.length != 2) {
			return;
		}
		while (true) {

			//Check if the row and col are outside of the board
			if (game.getBoardSize() < 0 || game.getBoardSize() < 0 || game.getBoardSize() >= game.getBoardSize() || game.getBoardSize() >= game.getBoardSize()) {
				System.out.println("This position is off the bounds of the board! Try again.");

				//Otherwise, the position is valid so break out of the while loop
			} else {
				break;
			}
		}

		gameRepository.save(game);
	}
}
