package com.test.app.dherp.bean.projection;

public interface RoleProjection {
    Long getId();

    String getName();

    String getStatus();
}
