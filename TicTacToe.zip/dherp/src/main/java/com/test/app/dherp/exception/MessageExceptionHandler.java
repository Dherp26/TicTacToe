package com.test.app.dherp.exception;

import com.test.app.dherp.bean.GeneralWrapper;
import com.test.app.dherp.service.MessageSourceService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class MessageExceptionHandler extends ResponseEntityExceptionHandler {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final MessageSourceService messageSourceService;

    @Autowired
    public MessageExceptionHandler(MessageSourceService messageSourceService) {
        this.messageSourceService = messageSourceService;
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> general(Exception ex) {
        handleErrorMessage(ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new GeneralWrapper<>().fail(ex, "Unexpected Error"));
    }

    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<?> unauthorized(AuthenticationException ex) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(new GeneralWrapper().fail(ex, HttpStatus.UNAUTHORIZED.getReasonPhrase()));
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<?> forbidden(AccessDeniedException ex) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(new GeneralWrapper().fail(ex, HttpStatus.FORBIDDEN.getReasonPhrase()));
    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<?> badRequest(BadRequestException ex) {
        if (StringUtils.isNotBlank(ex.getCode()) &&
                StringUtils.isNotBlank(ex.getProperty())) {
            if (ex.isLogErrorMessage()) {
                handleErrorMessage(ex);
            }
            String message = (StringUtils.isBlank(ex.getErrorMessage()))
                    ? messageSourceService.getMessage(ex.getProperty())
                    : ex.getErrorMessage();
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(new GeneralWrapper<>().fail(ex.getCode(), message));
        } else {
            if (ex.isLogErrorMessage()) {
                handleErrorMessage(ex);
            }
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(new GeneralWrapper<>().fail(ex));
        }
    }

    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {
        handleErrorMessage(ex);
        super.handleExceptionInternal(ex, body, headers, status, request);
        return ResponseEntity
                .status(status)
                .headers(headers)
                .body(new GeneralWrapper<>().fail(ex, status.getReasonPhrase()));
    }

    private void handleErrorMessage(Exception ex) {
        logger.error("Error : ", ex);
    }

}
