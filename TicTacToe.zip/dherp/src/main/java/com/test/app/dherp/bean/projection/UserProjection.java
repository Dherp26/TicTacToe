package com.test.app.dherp.bean.projection;

public interface UserProjection {
    Long getId();

    String getName();

    String getEmail();

    String getStatus();

    String getRoleName();
    Long getRoleId();
    String getRoleStatus();
}
