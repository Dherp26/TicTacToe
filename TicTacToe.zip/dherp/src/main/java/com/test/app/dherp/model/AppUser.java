package com.test.app.dherp.model;

import com.test.app.dherp.base.BaseAuditedEntity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Getter
@Setter
public class AppUser extends BaseAuditedEntity {

    @Id
    @GeneratedValue
    private Long id;

    private String username;

    private String password;
    private String boardSize;

}
